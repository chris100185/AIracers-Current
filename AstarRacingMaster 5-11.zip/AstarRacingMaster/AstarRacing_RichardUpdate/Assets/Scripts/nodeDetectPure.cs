﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class nodeDetectPure : MonoBehaviour
{
    public GameObject driveObj;
    AiCar3 carAi;
    drivingPure drive;

    // Use this for initialization
    void Start()
    {
        
        drive = driveObj.GetComponent<drivingPure>();
        carAi = gameObject.GetComponent<AiCar3>();
        //ive.nextNode(carAi.initNode());
       
    }

    // Update is called once per frame
    void Update()
    {
      

    }
    public void OnTriggerEnter2D(Collider2D collision)
    {
        //print("processing collision");
        if (collision.gameObject.tag == "node")//we've hit a node, let driving AI know it's time to move to the next one
        {       
            //check to ensure that the node we collided with is our target       
            if (collision.gameObject != drive.destination)
            {
               // drive.car.Turn(1);
                return;
            }

            drive.nextNode(carAi.nextNode());
            //GetNode(open,closed,drive.destination)
        }


    }    

}
