﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class compute_ai2_node : MonoBehaviour {

    public GameObject driveObj;
    AI2_path driver;
    [SerializeField]
    public List<GameObject> waypoints;
    [SerializeField]
    public List<GameObject> starpoints;
    public List<GameObject> open;
    public List<GameObject> closed;
    public List<GameObject> other;
    public List<GameObject> goal;
    public GameObject set;
    //public int j;

    // Use this for initialization
    void Start()
    {
        driver = driveObj.GetComponent<AI2_path>();
        Astar();
        for (int i = 0; i < waypoints.Count; i++)
        {
            closed.Insert(i, waypoints[i]);
        }
        closed.RemoveAt(0);
        closed.RemoveAt(0);
        
    }

    // Update is called once per frame
    void Update()
    {
        driver = driveObj.GetComponent<AI2_path>();

    }
    public void OnTriggerEnter2D(Collider2D collision)
    {
        //print("processing collision");
        if (collision.gameObject.tag == "node")//we've hit a node, let driving AI know it's time to move to the next one
        {
            //Opencheck();


            // drive.NextTarget();
            //check to ensure that the node we collided with is our target
            if (driver.nextTarget == null)
            {
                driver.nextTarget = starpoints[1];
            }
            if (collision.gameObject != driver.destination)
            {
                // drive.car.Turn(1);
                return;
            }

            Opencheck();
            driver.nextNode();
            //GetNode(open,closed,drive.destination)
        }


    }
    public GameObject GetNode()
    {
        print("Enter getnode");
        set = closed[0];
        closed.RemoveAt(0);
       
        print("going to " + set.name);
        return set;
    }
    public void Opencheck()
    {
        if (closed.Count == 0)
        {
            for (int i = 0; i < other.Count - 1; i++)
            {
                closed.Insert(i, other[i]);
            }
            //closed = new GameObject[waypoints.Count];

        }
    }
    public void Astar()
    {
        int j = 0;
        float f, g, h;
        GameObject check1, check2;
        for (int i = 0; i < starpoints.Count; i++)
        {
            open.Insert(i, starpoints[i]);
        }
        //f(n) = g(n) + h(n)
        //g(n) = total dist from start node[0] to where current node
        //h(n)= dist from current node to last node[]
        other.Insert(0, starpoints[0]);
        j++;
        open.RemoveAt(0);
        while (open.Count > 0)
        {

            check1 = open[0];
            check2 = open[1];
            g = Vector2.Distance(other[0].transform.position, check1.transform.position);
            h = Vector2.Distance(check1.transform.position, starpoints[starpoints.Count - 1].transform.position);
            f = g + h;

            g = Vector2.Distance(other[0].transform.position, check2.transform.position);
            h = Vector2.Distance(check2.transform.position, starpoints[starpoints.Count - 1].transform.position);
            if (f > (g + h)) //use check1
            {
                //f = g + h;
                other.Insert(j, check1);
                open.RemoveAt(0);
                j++;
            }
            else
            {
                other.Insert(j, check2);
                open.RemoveAt(0);
                open.RemoveAt(0);
                j++;

            }
            if (open.Count == 1)
            {
                other.Insert(j, open[0]);
                break;
            }
            f = 0; g = 0; h = 0;
           



        }
        //waypoints.Insert(0, starpoints[1]);
        for (int i = 0; i < other.Count; i++)
        {
            waypoints.Insert(i,other[i]); //found best path to use for car
        }

    }
}
